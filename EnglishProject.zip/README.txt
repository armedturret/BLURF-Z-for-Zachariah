Hello Mr.Jenkins,


This document describes all the files in this folder and how to use them.



Blurf.exe: The main executable for the project. Double click on it to run it. The window that appears will tell you some story then you must type what you want to do. The first part will ask for a compass direction to go in so say go <direction>.

IMPORTANT: If you receive a "dll missing" error, run vcredist(x86) to fix it. This is caused by your computer missing some stuff c++ needs to run and will install it automagically.



<Direction> Cheat Sheet.txt: A list of all possible story paths from the initial choice of that direction. More detailed instructions inside.



Deps.eng: Don't open this file as its something the engine needs to run and is general nonsense to the human eye.

Credits.txt: The credits for the project.

Tips:
Don't make ambiguous actions i.e. say "jump over bar" rather than "jump over"
Say "cancel" to stop examining something i.e. if you say "open door" but it says you don't have a key say "cancel"
All actions must include a verb i.e. "go north" instead of "north"